# TabProject_1

This was a school project itended to showcase Android componets and classes such as:
-Activities 
-Fragments
-UI views 
-View adpater classes
-XML layouts 
-Resource files 
-Firebase database intstances

All of these components in addtion to object oriented design concepts come together to build an functional To-do list aplllication. 

This project uses a firebase databse instance to show how data can be created,read,updated and deleted.
