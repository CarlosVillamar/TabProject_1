package com.example.carlos.tabproject1;

public class TabNames {
    //getter and setter class for tab names for a future update
    private String Tab = " ";

    public String setTab(String TabName){
        this.Tab = TabName;
        return TabName;
    }

    public String getTab(){return Tab;}
}
